package com.onelove.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.view.View

class RastaPalette(
    val name: String,
    val colors: IntArray,
    val stops: FloatArray,
    val scrim: Int,
    val accent: Int
)

private fun c(v: Long) = v.toInt()

val PALETTES = listOf(
    RastaPalette(
        "Roots Classic",
        intArrayOf(c(0xFFC1272D), c(0xFFC1272D), c(0xFFF2B705), c(0xFFF2B705), c(0xFF1E8E3E), c(0xFF1E8E3E)),
        floatArrayOf(0f, .333f, .333f, .667f, .667f, 1f),
        c(0xA6000000), c(0xFFF2B705)
    ),
    RastaPalette(
        "Deep Forest",
        intArrayOf(c(0xFF14532D), c(0xFF031009)),
        floatArrayOf(0f, 1f),
        c(0x33000000), c(0xFF7BD35B)
    ),
    RastaPalette(
        "Golden Hour",
        intArrayOf(c(0xFFF2B705), c(0xFFB3472B), c(0xFF2A0F0A)),
        floatArrayOf(0f, .5f, 1f),
        c(0x40000000), c(0xFFFFD45C)
    )
)

class BgView(context: Context) : View(context) {
    private val paint = Paint()
    private val scrimPaint = Paint()

    var palette: RastaPalette = PALETTES[0]
        set(value) {
            field = value
            rebuild()
            invalidate()
        }

    init { rebuild() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        rebuild()
    }

    private fun rebuild() {
        scrimPaint.color = palette.scrim
        if (height > 0) {
            paint.shader = LinearGradient(
                0f, 0f, 0f, height.toFloat(), palette.colors, palette.stops, Shader.TileMode.CLAMP
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), scrimPaint)
    }
}
