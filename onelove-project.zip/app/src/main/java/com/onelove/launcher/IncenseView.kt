package com.onelove.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** A burning incense stick in a brass dish, with drifting smoke. Tap handling is done by the host. */
class IncenseView(context: Context) : View(context) {

    private class Puff(
        var x: Float, var y: Float, val vx: Float, val vy: Float,
        val phase: Float, val life: Float, val size: Float, var age: Float = 0f
    )

    var lit = false
        private set

    private var burn = 0f
    private val puffs = ArrayList<Puff>()
    private var last = 0L
    private var emitAcc = 0f
    private var tipX = 0f
    private var tipY = 0f
    private val tilt = Math.toRadians(10.0)

    private val soft: Bitmap = makeSoft()
    private val smokePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND; strokeWidth = dpf(3.5f); color = 0xFF8A5A2B.toInt()
    }
    private val ashStickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND; strokeWidth = dpf(3.5f); color = 0xFFA9A9A2.toInt()
    }
    private val dishPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFB98A2E.toInt() }
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFF1CE74.toInt(); style = Paint.Style.STROKE; strokeWidth = dpf(2f)
    }
    private val sandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3B2E1E.toInt() }
    private val ashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF9A9A94.toInt() }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(
            0f, 0f, dpf(16f),
            intArrayOf(0xFFFFE9A0.toInt(), 0xCCFF7A12.toInt(), 0x00FF3D00),
            floatArrayOf(0f, .35f, 1f), Shader.TileMode.CLAMP
        )
    }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFF4C8.toInt() }
    private val rect = RectF()

    init { isClickable = true }

    private fun makeSoft(): Bitmap {
        val bmp = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(
            32f, 32f, 32f,
            intArrayOf(0xFFFFFFFF.toInt(), 0x66FFFFFF, 0x00FFFFFF),
            floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP
        )
        Canvas(bmp).drawCircle(32f, 32f, 32f, p)
        return bmp
    }

    fun light() {
        if (burn >= 0.98f) burn = 0f
        lit = true
        last = 0L
        invalidate()
    }

    fun extinguish() {
        lit = false
        invalidate()
    }

    /** A thick burst of smoke (used on each cough). */
    fun puff() {
        repeat(16) { emit(true) }
        invalidate()
    }

    private fun emit(big: Boolean) {
        if (puffs.size > 220) return
        val k = if (big) 1.4f else 1f
        puffs.add(
            Puff(
                tipX + (Random.nextFloat() - .5f) * dpf(4f), tipY,
                (Random.nextFloat() - .5f) * dpf(14f),
                -(dpf(30f) + Random.nextFloat() * dpf(25f)) * k,
                Random.nextFloat() * 6.28f,
                (if (big) 4f else 3f) + Random.nextFloat() * 1.5f,
                dpf(26f) + Random.nextFloat() * dpf(16f)
            )
        )
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 16L else minOf(now - last, 50L)
        last = now
        val s = dt / 1000f

        val cx = width / 2f
        val baseY = height - dpf(34f)
        val total = height * 0.55f

        if (lit) {
            burn += s / 90f
            if (burn >= 1f) { burn = 1f; lit = false }
        }
        val len = total * (1f - burn) + dpf(6f)
        val dx = sin(tilt).toFloat()
        val dy = -cos(tilt).toFloat()
        val sx = cx
        val sy = baseY - dpf(10f)
        tipX = sx + dx * len
        tipY = sy + dy * len

        // dish
        rect.set(cx - dpf(70f), baseY - dpf(6f), cx + dpf(70f), baseY + dpf(22f))
        canvas.drawOval(rect, dishPaint)
        canvas.drawOval(rect, rimPaint)
        rect.set(cx - dpf(58f), baseY - dpf(2f), cx + dpf(58f), baseY + dpf(14f))
        canvas.drawOval(rect, sandPaint)

        // ash heap
        val aw = dpf(10f) + burn * dpf(40f)
        val ah = dpf(3f) + burn * dpf(8f)
        rect.set(cx - aw, baseY + dpf(5f) - ah, cx + aw, baseY + dpf(5f) + ah)
        canvas.drawOval(rect, ashPaint)

        // stick (+ ash column above the ember)
        canvas.drawLine(sx, sy, tipX, tipY, stickPaint)
        if (lit) {
            canvas.drawLine(tipX, tipY, tipX + dx * dpf(12f), tipY + dy * dpf(12f), ashStickPaint)
        }

        // smoke
        if (lit) {
            emitAcc += s * 35f
            while (emitAcc >= 1f) { emitAcc -= 1f; emit(false) }
        }
        val it = puffs.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.age += s
            if (p.age >= p.life) { it.remove(); continue }
            val f = p.age / p.life
            p.x += p.vx * s
            p.y += p.vy * s
            val sway = sin(p.age * 2.2f + p.phase) * dpf(10f) * f
            val r = p.size * (0.25f + f)
            val fadeIn = if (f < 0.1f) f / 0.1f else 1f
            smokePaint.alpha = ((1f - f) * fadeIn * 110f).toInt()
            canvas.save()
            canvas.translate(p.x + sway, p.y)
            canvas.scale(r / 32f, r / 32f)
            canvas.drawBitmap(soft, -32f, -32f, smokePaint)
            canvas.restore()
        }

        // ember
        if (lit) {
            val pulse = 0.85f + 0.15f * sin(now / 120.0).toFloat()
            canvas.save()
            canvas.translate(tipX, tipY)
            canvas.scale(pulse, pulse)
            canvas.drawCircle(0f, 0f, dpf(16f), glowPaint)
            canvas.drawCircle(0f, 0f, dpf(2.2f), corePaint)
            canvas.restore()
        }

        if (lit || puffs.isNotEmpty()) postInvalidateOnAnimation()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) {
            last = 0L
            postInvalidateOnAnimation()
        }
    }
}
