package com.onelove.launcher

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("onelove", Context.MODE_PRIVATE)

    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }

    var leaves: Boolean
        get() = sp.getBoolean("leaves", true)
        set(v) { sp.edit().putBoolean("leaves", v).apply() }

    var dock: List<String>
        get() = (sp.getString("dock", "") ?: "").split("|").filter { it.isNotEmpty() }
        set(v) { sp.edit().putString("dock", v.joinToString("|")).apply() }

    var hidden: Set<String>
        get() = (sp.getStringSet("hidden", emptySet()) ?: emptySet()).toSet()
        set(v) { sp.edit().putStringSet("hidden", v.toSet()).apply() }
}
