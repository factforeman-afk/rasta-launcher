package com.onelove.launcher

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.SoundPool
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Calendar
import java.util.concurrent.Executors

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

private val QUOTES = listOf(
    "One love starts with one calm breath.",
    "Slow burn, steady mind.",
    "Roots deep, spirit high.",
    "Good vibes grow where you plant them.",
    "Be like incense: leave something good in the air.",
    "Small steps, good rhythm.",
    "Peace is a daily practice.",
    "Walk easy, think positive."
)

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var bg: BgView
    private lateinit var leaves: LeafRainView
    private lateinit var home: LinearLayout
    private lateinit var incense: IncenseView
    private lateinit var status: TextView
    private lateinit var dock: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var search: EditText
    private lateinit var grid: RecyclerView
    private lateinit var adapter: AppAdapter
    private lateinit var sounds: SoundPool
    private lateinit var gestures: GestureDetector

    private val coughIds = IntArray(2)
    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var allApps = listOf<AppInfo>()
    private var drawerOpen = false

    private val cough1 = Runnable { cough(0, false) }
    private val cough2 = Runnable { cough(1, true) }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { loadApps() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(buildUi())
        applyTheme()
        setupSound()
        setupGestures()
        loadApps()

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    // ---------------------------------------------------------------- UI

    private fun roundBg(color: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dpf(radiusDp.toFloat())
        if (stroke != null) setStroke(1.dp, stroke)
    }

    private fun buildUi(): FrameLayout {
        val root = FrameLayout(this)

        bg = BgView(this)
        root.addView(bg, FrameLayout.LayoutParams(MATCH, MATCH))

        leaves = LeafRainView(this).apply { visibility = if (prefs.leaves) View.VISIBLE else View.GONE }
        root.addView(leaves, FrameLayout.LayoutParams(MATCH, MATCH))

        // ----- home layer
        home = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            isLongClickable = true
            setOnLongClickListener { showMenu(); true }
        }
        val clock = TextClock(this).apply {
            format12Hour = "h:mm"; format24Hour = "HH:mm"
            textSize = 72f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setShadowLayer(10f, 0f, 3f, 0x99000000.toInt())
        }
        home.addView(clock, LinearLayout.LayoutParams(WRAP, WRAP))

        val date = TextClock(this).apply {
            format12Hour = "EEEE, d MMMM"; format24Hour = "EEEE, d MMMM"
            textSize = 16f
            setTextColor(Color.WHITE)
            setShadowLayer(8f, 0f, 2f, 0x99000000.toInt())
        }
        home.addView(date, LinearLayout.LayoutParams(WRAP, WRAP))

        val quote = TextView(this).apply {
            text = "\u201C" + QUOTES[Calendar.getInstance().get(Calendar.DAY_OF_YEAR) % QUOTES.size] + "\u201D"
            textSize = 14f
            setTypeface(typeface, Typeface.ITALIC)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            alpha = .9f
            setShadowLayer(8f, 0f, 2f, 0x99000000.toInt())
        }
        home.addView(quote, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(32.dp, 14.dp, 32.dp, 0) })

        incense = IncenseView(this).apply { minimumHeight = 160.dp }
        incense.setOnClickListener { toggleIncense() }
        home.addView(incense, LinearLayout.LayoutParams(MATCH, 0, 1f).apply { topMargin = 8.dp })

        status = TextView(this).apply {
            text = "Tap the incense to light it"
            textSize = 14f
            gravity = Gravity.CENTER
            setShadowLayer(8f, 0f, 2f, 0x99000000.toInt())
        }
        home.addView(status, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(16.dp, 4.dp, 16.dp, 12.dp) })

        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(10.dp, 10.dp, 10.dp, 10.dp)
        }
        home.addView(dock, LinearLayout.LayoutParams(MATCH, 84.dp).apply { setMargins(24.dp, 0, 24.dp, 0) })

        val swipeHint = TextView(this).apply {
            text = "\u25B2 swipe up for apps  \u2022  long-press for settings"
            textSize = 11f
            setTextColor(0xCCFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        home.addView(swipeHint, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = 8.dp })
        root.addView(home, FrameLayout.LayoutParams(MATCH, MATCH))

        // ----- drawer layer
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xF2071209.toInt())
            visibility = View.GONE
            isClickable = true
        }
        val closeBtn = TextView(this).apply {
            text = "\u25BE"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setOnClickListener { closeDrawer() }
        }
        drawer.addView(closeBtn, LinearLayout.LayoutParams(MATCH, 40.dp))

        search = EditText(this).apply {
            setHint("Search apps\u2026")
            setHintTextColor(0x99FFFFFF.toInt())
            setTextColor(Color.WHITE)
            textSize = 16f
            inputType = InputType.TYPE_CLASS_TEXT
            maxLines = 1
            imeOptions = EditorInfo.IME_ACTION_GO
            background = roundBg(0x26FFFFFF, 24)
            setPadding(20.dp, 12.dp, 20.dp, 12.dp)
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { adapter.filter(s?.toString() ?: "") }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_GO) {
                    adapter.first()?.let { launch(it); closeDrawer() }
                    true
                } else false
            }
        }
        drawer.addView(search, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(8.dp, 0, 8.dp, 8.dp) })

        adapter = AppAdapter(
            onClick = { launch(it); closeDrawer() },
            onLong = { appMenu(it) }
        )
        grid = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 4)
            adapter = this@MainActivity.adapter
            clipToPadding = false
        }
        drawer.addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(drawer, FrameLayout.LayoutParams(MATCH, MATCH))

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, ins ->
            val bars = ins.getInsets(WindowInsetsCompat.Type.systemBars())
            val withIme = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            home.setPadding(0, bars.top + 16.dp, 0, bars.bottom + 8.dp)
            drawer.setPadding(12.dp, withIme.top + 4.dp, 12.dp, withIme.bottom + 8.dp)
            ins
        }
        return root
    }

    private fun applyTheme() {
        val p = PALETTES[prefs.theme % PALETTES.size]
        bg.palette = p
        status.setTextColor(p.accent)
        dock.background = roundBg(0x40000000, 28, p.accent)
    }

    // ---------------------------------------------------------------- gestures

    private fun setupGestures() {
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y
                if (!drawerOpen && -dy > 80.dp && vy < -800f) { openDrawer(); return true }
                if (drawerOpen && dy > 80.dp && vy > 800f && !grid.canScrollVertically(-1)) {
                    closeDrawer(); return true
                }
                return false
            }
        })
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (::gestures.isInitialized) gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (drawerOpen) closeDrawer()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (drawerOpen) closeDrawer()
    }

    private fun openDrawer() {
        drawerOpen = true
        drawer.animate().cancel()
        drawer.visibility = View.VISIBLE
        drawer.translationY = resources.displayMetrics.heightPixels.toFloat()
        drawer.animate().translationY(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        search.setText("")
        search.clearFocus()
        drawer.animate().cancel()
        drawer.animate().translationY(resources.displayMetrics.heightPixels.toFloat())
            .setDuration(220).withEndAction { if (!drawerOpen) drawer.visibility = View.GONE }.start()
    }

    // ---------------------------------------------------------------- apps

    private fun loadApps() {
        io.execute {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    AppInfo(
                        it.loadLabel(pm).toString(),
                        it.activityInfo.packageName,
                        it.activityInfo.name,
                        it.loadIcon(pm)
                    )
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                allApps = list
                refreshLists()
            }
        }
    }

    private fun refreshLists() {
        val hidden = prefs.hidden
        val visible = allApps.filter { it.pkg !in hidden }
        adapter.submit(visible)
        rebuildDock(visible)
    }

    private fun rebuildDock(visible: List<AppInfo>) {
        dock.removeAllViews()
        val items = prefs.dock.mapNotNull { pkg -> visible.firstOrNull { it.pkg == pkg } }.take(5)
        if (items.isEmpty()) {
            dock.addView(TextView(this).apply {
                text = "Long-press any app to pin it here"
                textSize = 12f
                setTextColor(0xCCFFFFFF.toInt())
            })
            return
        }
        for (app in items) {
            dock.addView(ImageView(this).apply {
                setImageDrawable(app.icon)
                layoutParams = LinearLayout.LayoutParams(56.dp, 56.dp).apply { setMargins(6.dp, 0, 6.dp, 0) }
                setOnClickListener { launch(app) }
                setOnLongClickListener { appMenu(app); true }
            })
        }
    }

    private fun launch(app: AppInfo) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(app.pkg, app.cls))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try { startActivity(i) } catch (e: Exception) {
            Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun appMenu(app: AppInfo) {
        val pinned = app.pkg in prefs.dock
        val opts = arrayOf(if (pinned) "Remove from dock" else "Pin to dock", "Hide app", "App info / uninstall")
        AlertDialog.Builder(this).setTitle(app.label).setItems(opts) { _, which ->
            when (which) {
                0 -> {
                    val d = prefs.dock
                    if (pinned) prefs.dock = d - app.pkg
                    else if (d.size >= 5) Toast.makeText(this, "Dock is full (5 apps)", Toast.LENGTH_SHORT).show()
                    else prefs.dock = d + app.pkg
                    refreshLists()
                }
                1 -> {
                    prefs.hidden = prefs.hidden + app.pkg
                    prefs.dock = prefs.dock - app.pkg
                    refreshLists()
                    Toast.makeText(this, "Hidden. Restore it from the home-screen menu.", Toast.LENGTH_LONG).show()
                }
                2 -> try {
                    startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) { }
            }
        }.show()
    }

    // ---------------------------------------------------------------- menu

    private fun showMenu() {
        val p = PALETTES[prefs.theme % PALETTES.size]
        val items = arrayOf(
            "Theme: ${p.name} (tap to change)",
            "Falling leaves: ${if (prefs.leaves) "ON" else "OFF"}",
            "Hidden apps (${prefs.hidden.size})",
            "Set as default home app",
            "About"
        )
        AlertDialog.Builder(this).setTitle("One Love Launcher").setItems(items) { _, which ->
            when (which) {
                0 -> { prefs.theme = (prefs.theme + 1) % PALETTES.size; applyTheme() }
                1 -> {
                    prefs.leaves = !prefs.leaves
                    leaves.visibility = if (prefs.leaves) View.VISIBLE else View.GONE
                }
                2 -> showHidden()
                3 -> try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) } catch (e: Exception) { }
                4 -> AlertDialog.Builder(this).setTitle("One Love Launcher")
                    .setMessage("Version 1.0\nNo ads. No tracking. No permissions.\nSwipe up for apps, long-press for settings.")
                    .setPositiveButton("OK", null).show()
            }
        }.show()
    }

    private fun showHidden() {
        val hiddenApps = allApps.filter { it.pkg in prefs.hidden }
        if (hiddenApps.isEmpty()) {
            Toast.makeText(this, "No hidden apps", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Tap an app to unhide")
            .setItems(hiddenApps.map { it.label }.toTypedArray()) { _, w ->
                prefs.hidden = prefs.hidden - hiddenApps[w].pkg
                refreshLists()
            }.show()
    }

    // ---------------------------------------------------------------- incense + coughs

    private fun setupSound() {
        sounds = SoundPool.Builder()
            .setMaxStreams(2)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            ).build()
        coughIds[0] = sounds.load(this, R.raw.cough1, 1)
        coughIds[1] = sounds.load(this, R.raw.cough2, 1)
    }

    private fun toggleIncense() {
        if (incense.lit) {
            incense.extinguish()
            ui.removeCallbacks(cough1)
            ui.removeCallbacks(cough2)
            status.text = "Incense put out. Peace."
        } else {
            incense.light()
            status.text = "Burning\u2026 breathe slowly"
            ui.postDelayed(cough1, 2500)
            ui.postDelayed(cough2, 3800)
        }
    }

    private fun cough(index: Int, last: Boolean) {
        if (!incense.lit) return
        sounds.play(coughIds[index], 1f, 1f, 1, 0, 1f)
        incense.puff()
        incense.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        ObjectAnimator.ofFloat(home, "translationX", 0f, -14f, 14f, -10f, 10f, -5f, 0f)
            .setDuration(380).start()
        status.text = if (last) "*cough* *cough* \u2014 strong incense!" else "*cough*"
        if (last) ui.postDelayed({
            if (incense.lit) status.text = "Burning\u2026 tap to put it out"
        }, 3000)
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacksAndMessages(null)
        sounds.release()
        io.shutdown()
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) { }
    }
}
