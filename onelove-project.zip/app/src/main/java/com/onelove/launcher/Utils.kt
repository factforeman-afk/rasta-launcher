package com.onelove.launcher

import android.content.res.Resources

val Int.dp: Int get() = (this * Resources.getSystem().displayMetrics.density).toInt()
fun dpf(v: Float): Float = v * Resources.getSystem().displayMetrics.density
