package com.onelove.launcher

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class AppInfo(val label: String, val pkg: String, val cls: String, val icon: Drawable)

class AppAdapter(
    private val onClick: (AppInfo) -> Unit,
    private val onLong: (AppInfo) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var all: List<AppInfo> = emptyList()
    private var shown: List<AppInfo> = emptyList()
    private var query = ""

    class VH(val root: LinearLayout, val icon: ImageView, val label: TextView) : RecyclerView.ViewHolder(root)

    fun submit(list: List<AppInfo>) { all = list; applyFilter() }
    fun filter(q: String) { query = q.trim().lowercase(); applyFilter() }
    fun first(): AppInfo? = shown.firstOrNull()

    @SuppressLint("NotifyDataSetChanged")
    private fun applyFilter() {
        shown = if (query.isEmpty()) all else all.filter { it.label.lowercase().contains(query) }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(4.dp, 10.dp, 4.dp, 10.dp)
            layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val icon = ImageView(ctx)
        root.addView(icon, LinearLayout.LayoutParams(56.dp, 56.dp))
        val label = TextView(ctx).apply {
            textSize = 11f
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
        }
        root.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 4.dp })
        return VH(root, icon, label)
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val app = shown[position]
        h.icon.setImageDrawable(app.icon)
        h.label.text = app.label
        h.root.setOnClickListener { onClick(app) }
        h.root.setOnLongClickListener { onLong(app); true }
    }

    override fun getItemCount() = shown.size
}
