package com.onelove.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.view.View
import kotlin.math.sin
import kotlin.random.Random

/** Slowly drifting cannabis leaves in the background. */
class LeafRainView(context: Context) : View(context) {
    private class Leaf(
        var x: Float, var y: Float, val size: Float, val speed: Float,
        var rot: Float, val spin: Float, val sway: Float, val phase: Float, val alpha: Int
    )

    private val drawable: Drawable = context.getDrawable(R.drawable.ic_leaf)!!
    private val leaves = ArrayList<Leaf>()
    private var last = 0L
    private var t = 0f

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        leaves.clear()
        repeat(12) { leaves.add(spawn(true)) }
    }

    private fun spawn(initial: Boolean): Leaf {
        val s = dpf(26f) + Random.nextFloat() * dpf(34f)
        return Leaf(
            Random.nextFloat() * width,
            if (initial) Random.nextFloat() * height else -s,
            s,
            dpf(18f) + Random.nextFloat() * dpf(30f),
            Random.nextFloat() * 360f,
            (Random.nextFloat() - .5f) * 40f,
            dpf(10f) + Random.nextFloat() * dpf(24f),
            Random.nextFloat() * 6.28f,
            40 + Random.nextInt(60)
        )
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 16L else minOf(now - last, 50L)
        last = now
        val s = dt / 1000f
        t += s
        for (i in leaves.indices) {
            var l = leaves[i]
            l.y += l.speed * s
            l.rot += l.spin * s
            if (l.y - l.size > height) {
                l = spawn(false)
                leaves[i] = l
            }
            val x = l.x + sin(t * 1.2f + l.phase) * l.sway
            val half = (l.size / 2).toInt()
            canvas.save()
            canvas.translate(x, l.y)
            canvas.rotate(l.rot)
            drawable.setBounds(-half, -half, half, half)
            drawable.alpha = l.alpha
            drawable.draw(canvas)
            canvas.restore()
        }
        postInvalidateOnAnimation()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) {
            last = 0L
            postInvalidateOnAnimation()
        }
    }
}
