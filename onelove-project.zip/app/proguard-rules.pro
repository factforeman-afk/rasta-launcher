# default rules are enough; app uses no reflection
